package main

import (
	"fmt"
	"net"
	"log"
	"os"
	"strconv"
	"io/ioutil"
	 pb  "samespace.com/router/api"
	"github.com/sirupsen/logrus"

	
	"io"
	"net/url"


	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"

	texttospeech "cloud.google.com/go/texttospeech/apiv1"
	texttospeechpb "google.golang.org/genproto/googleapis/cloud/texttospeech/v1"

	"github.com/aws/aws-sdk-go/aws"
        "github.com/aws/aws-sdk-go/aws/session"
        "github.com/aws/aws-sdk-go/service/polly"
	"encoding/json"
	"github.com/gorilla/websocket"

	"github.com/joho/godotenv"
)


// Variables
var sessionData *Session
var result chan []byte

//Structure
type Session struct { 
	ws *websocket.Conn
	data chan []byte
	message chan string
	size chan int
	connect bool
}

type Speech struct {
        Result []Result `json:"result"`
        Text   string   `json:"text"`
}

type Result struct {
        Word  string  `json:"word"`
        Start float64 `json:"start"`
        End   float64 `json:"end"`
        Conf  float64 `json:"conf"`
}

type TextToSpeechServer struct{}


func connectWebServer(s *Session) () {
 	u := url.URL{Scheme: "ws", Host: os.Getenv("WEBSOCKET_URL"), Path: "/"}
        logrus.Info("connecting to ", u.String())

	ws, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
        if err != nil {
                log.Fatal("dial Fail:", err)
        }

	sessionData.ws = ws
	sessionData.connect = true
}

func newSessionObject() *Session {
	return &Session {
		ws:  new(websocket.Conn),
		data:  make(chan []byte),
		message: make(chan string),
		size: make(chan int),
		connect: false,
	}
}

func createPollyClient() *polly.Polly {
        session := session.Must(session.NewSessionWithOptions(session.Options{
                SharedConfigState: session.SharedConfigEnable,
        }))

        return polly.New(session)
}

func main() {

	env := godotenv.Load() //Load .env file
        if env != nil{
                 logrus.Fatalf("Failed to read config file")
		 return
        }

	sessionData = newSessionObject()
	result = make(chan []byte)

	err := os.Setenv("GOOGLE_APPLICATION_CREDENTIALS",os.Getenv("CLIENT_ACCESS_KEYS"))
	 if err != nil {
		fmt.Println(err)
	}

	if os.Getenv("LOG_LEVEL") == "Debug"{
		logrus.SetLevel(logrus.DebugLevel)
	}

	var opts []grpc.ServerOption
	port, _ := strconv.Atoi(os.Getenv("SERVER_PORT"))
	creds, err := credentials.NewServerTLSFromFile(os.Getenv("CERT_PATH"), os.Getenv("KEY_PATH"))
        if err != nil {
            fmt.Errorf("could not load TLS keys: %s", err)
        }

	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", port))
	if err != nil {
		logrus.Fatalf("could not listen to port %d: %v, %v", port, err)
	} else {
		logrus.Info("listening to port ", port)
	}
	opts = []grpc.ServerOption{grpc.Creds(creds)}
	s := grpc.NewServer(opts...)
	pb.RegisterTextToSpeechServer(s, TextToSpeechServer{})
	err = s.Serve(lis)
	if err != nil {
		logrus.Fatalf("could not serve: %v", err)
	}
	defer sessionData.ws.Close()
}

func UnmarshalSpeech(data []byte) (Speech, error) {
	var r Speech
	err := json.Unmarshal(data, &r)
	return r, err
}

func (r *Speech) Marshal() ([]byte, error) {
	return json.Marshal(r)
}

func reader(s *Session) {
	defer func() {

		s.ws.Close()
	}()
	for {

		_, msg, err := s.ws.ReadMessage()
		if err != nil || err == io.EOF {
			sessionData.connect = false
			log.Printf("Close from serevr on Success: %v",err)
			break
		}
		logrus.Debug("\njson from webSocket:\n", string(msg));
		parse, _ := UnmarshalSpeech(msg)
		logrus.Debug("\nParsed Text:", parse.Text)
		result <- []byte(parse.Text)

	}
}


func (s *Session) manageWebsocket(quite chan bool) {
	logrus.Debug("Websocket Read-Write at work...")
	defer func() {
		s.ws.Close()
	}()
	go reader(s)
	for {
		select {
		case buf := <-s.data:
			if string(buf) == "END" {
				err := s.ws.WriteMessage(websocket.TextMessage, []byte("END"))
				if err != nil {
					return
				}
			} else {
				err := s.ws.WriteMessage(websocket.BinaryMessage, buf)
				if err != nil {
					return
				}
			}

		case <-quite:
			return
		}
	}
}

func invoker() {
	q := make(chan bool)
	go  sessionData.manageWebsocket(q)
}

func (TextToSpeechServer) Asr(ctx context.Context, text *pb.Speech) (*pb.Speech, error) {

	if len(text.Audio) == 0 {
                //return &pb.Speech {Audio: []byte("")}, nil
        }

	if !sessionData.connect {
		connectWebServer(sessionData)
		invoker()
	}

	sessionData.data <- text.Audio

	if string(text.Audio) == "END" {
        return &pb.Speech {Audio: <-result}, nil

	} 
        return &pb.Speech {Audio: []byte("")}, nil
}
func (TextToSpeechServer) Say(ctx context.Context, text *pb.Text) (*pb.Speech, error) {

	logrus.Debug("Received Param-> [Text: ", text.Text,"] [VoiceName: ", text.VoiceName,"] [SsmlVoiceGender: ", text.SsmlVoiceGender,"] [AudioEncoding: ", text.AudioEncoding,"] [AudioSpeechRate: ", text.AudioSpeechRate,"] [AudioPitch: ", text.AudioPitch,"] [VoiceLanguageCode: ", text.VoiceLanguageCode,"] [GooglePollySamespace: ", text.GooglePollySamespace,"]");


      var data []byte
      switch text.GooglePollySamespace{
      case 1:
	{
	   for ok := true; ok; ok = false {
		ctx1 := context.Background()

		client, err := texttospeech.NewClient(ctx1)
		if err != nil {
			log.Fatal(err)
		}

		ttsText := text.Text
		// Perform the text-to-speech request on the text input with the selected
		// voice parameters and audio file type.
		req := texttospeechpb.SynthesizeSpeechRequest{
			// Set the text input to be synthesized.
			Input: &texttospeechpb.SynthesisInput{
				InputSource: &texttospeechpb.SynthesisInput_Text{Text: ttsText},
			},
			// Build the voice request, select the language code ("en-US") and the SSML
			// voice gender ("neutral").
			Voice: &texttospeechpb.VoiceSelectionParams{
				LanguageCode: text.VoiceLanguageCode,
				SsmlGender:   texttospeechpb.SsmlVoiceGender_FEMALE,
				Name:         text.VoiceName,
			},
			// Select the type of audio file you want returned.
			AudioConfig: &texttospeechpb.AudioConfig{
				AudioEncoding: texttospeechpb.AudioEncoding_LINEAR16,
				Pitch:         float64(text.AudioPitch),
				SpeakingRate:  float64(text.AudioSpeechRate),
				SampleRateHertz: 8000,
			},
		}

		resp, err := client.SynthesizeSpeech(ctx, &req)
		if err != nil {
			log.Fatal("1:Failed fetch audio content with ERROR: ",err)
			break
		}
		logrus.Debug("1:Audio data received text");
		data = resp.AudioContent
	   }
	}
     case 2:
	{
	  for ok := true; ok; ok = false {
		pollyClient := createPollyClient()
		input := &polly.SynthesizeSpeechInput{
			OutputFormat : aws.String("pcm"),
			Text : aws.String(text.Text),
			VoiceId : aws.String("Aditi"),
			Engine : aws.String("standard"),
			LanguageCode : aws.String("en-US"),
		}
		resp, err := pollyClient.SynthesizeSpeech(input)
		if err != nil {
			log.Fatal("2:Failed fetch audio content with ERROR: ",err)
			break
		}
		data, err = ioutil.ReadAll(resp.AudioStream)
		if err != nil {
			logrus.Fatalf("2: Audio stream conversion fail with ERROR: ", err)
			break
		}
		logrus.Debug("2:Audio data received for text")
	  }
	}
     }
     return &pb.Speech{Audio: data}, nil
}

func (s TextToSpeechServer) BiAsr(stream pb.TextToSpeech_BiAsrServer) error {

        for {
//              var ws *websocket.Conn
                text, err := stream.Recv()
                log.Println("ATUL received text: "+ string(text.Audio))
                if err != nil {
                         log.Println(err)
                }

                if  string(text.Audio) == "END" {
                        return nil
                }
                if err := stream.Send(&pb.Speech {Audio: []byte("Empty")}); err != nil {
                                return err
                        }

                        //c.Close()
        }
}
