# gRPC Basics: PHP sample code

The files in this folder are the samples used in [gRPC Basics: PHP][],
a detailed tutorial for using gRPC in PHP.

[gRPC Basics: PHP]:https://grpc.io/docs/tutorials/basic/php.html
